﻿namespace part1C
{

    class Program
    {
        static void Main(string[] args)
        {
            // this is my array 
           Recipe d = new Recipe();
            bool Entering = true;

            while (Entering)
            {
                Console.WriteLine("   HI,  welcome to the  app ");
               
                d.Details();

                Console.WriteLine("\n every ingredient:");
                d.Display();

                Console.WriteLine("\nEnter 'scale' to adjust the recipe's scale, 'relaunch' to reset quantities, 'clear' to clear all data, or 'exit' to exit the page  ");
                string input = Console.ReadLine().ToLower();

                switch (input)
                {
                    case "scale":
                        Console.WriteLine("Enter the Measurement factor (0.5 , 2 , 3 ):");
                        double factor = double.Parse(Console.ReadLine());
                        d.scale(factor);
                        Console.WriteLine("\n Measurement Recipe:");
                        //The customer shall be able to request that the recipe
                        d.Display();
                        
                        break;
                    case "relaunch":
                        //
                        d.Values();
                        Console.WriteLine("\nQuantities reset to original values.");
                        break;
                    case "clear":
                        d.Clear();
                        Console.WriteLine("\n Every data  are removed.");
                        break;
                    case "exit ":

                        Entering = false;

                        break;
                    default:
                        Console.WriteLine(" Ouff !!!!  you have entered a invalid  item .");
                        break;
                }
            }
        }
    }

    class Recipe
    {
        private string[] ts;
        private string[] steps;

        public void Details()
        {
            // The user shall be able to enter the details for a single recipe
            Console.WriteLine("Please enter the number of    ingredients  that u want to process   ? :");
            int numIngredients = int.Parse(Console.ReadLine());
            ts = new string[numIngredients];

            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Enter the name, quantity, and unit of measurement for ingredient {i + 1}:");
                ts[i] = Console.ReadLine();
            }
            //The number of ingredients.
            Console.WriteLine(" the number of steps:");
             int numSteps = int.Parse(Console.ReadLine());
            steps = new string[numSteps];

            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Enter step {i + 1}:");
                steps[i] = Console.ReadLine();
            }
        }

        public void Display()
        {
            Console.WriteLine("\nIngredients:");
            foreach (string ingredient in ts)
            {
                Console.WriteLine("- " + ingredient);
            }

            Console.WriteLine("\nStep:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
        }

        public void scale(double factor)
        {
            for (int i = 0; i < ts.Length; i++)
            {
                string[] parts = ts[i].Split(' ');
                double quantity = double.Parse(parts[0]);
                quantity *= factor;
                ts[i] = $"{quantity} {parts[1]} {parts[2]}";
            }
        }

        public void Values()
        {
            // Return amounts to their starting points.
            //assuming that after entering the recipe specifics, the previous values remain unchanged
        }

        public void Clear()
        {

            ts = null;
            steps = null;
        }
    }
} 

